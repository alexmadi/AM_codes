export default window.__CONFIG__;

'use strict';

//PLUGINS
var gulp = require('gulp'),
    gulpies = {
        sourcemaps: require('gulp-sourcemaps'),
        uglify: require('gulp-uglify'),
        sass: require('gulp-sass'),
        sassUnicode: require('gulp-sass-unicode'),
        postcss: require('gulp-postcss'),
        minifycss: require('gulp-minify-css'),
        imagemin: require('gulp-imagemin'),
        util: require('gulp-util')
    },
    settings = require('./package.json').settings, // Philipp Plein Build Settings
    //js
    browserify = require('browserify'),
    //css
    autoprefixer = require ("autoprefixer"),
    mqpacker = require ("css-mqpacker"),
    imageInliner = require ("postcss-image-inliner"),
    discardComments = require ("postcss-discard-comments"),
    spritesmith = require('gulp.spritesmith'),
    iconfont = require('gulp-iconfont'),
    iconfontCss = require('gulp-iconfont-css'),
    //streams
    watchify = require('watchify'),
    buffer = require('vinyl-buffer'),
    source = require('vinyl-source-stream'),
    //git
    guppy = require('git-guppy')(gulp),
    //dw auto-upload
    pathnode = require('path'),
    Promise = require('promise'),
    dwdav = null;

//MODES
var compress = false,
    watch = false,
    upload = false,
    dwConfig = null;

gulp.task('run-compress-mode', function () {compress = true;});
gulp.task('run-watch-mode', function () {watch = true;});
gulp.task('run-upload-mode', function () {
    try {
        dwdav = require('dwdav');
        dwConfig = require('./dw.json');
        upload = true;
    } catch (error) {
        gulpies.util.log(gulpies.util.colors.yellow(
                'DW Auto-upload: dw.json is not defined, upload is not possible'), error);
    }
});

/*
 * Compiles JavaScript
 */
gulp.task('js', function () {
    var opts = {
        entries: './' + settings.cartridge_name + settings.paths.js.src + settings.paths.js.app,
        debug: true,
        paths : [settings.paths.js.modules]
    };

    var bundler = browserify(opts);
    if (watch) {
        bundler = watchify(bundler);
    }
    /*
     * Transform modules from basic SiteGenesis cartridges
     */
    bundler.transform({
        aliases : {},
        replacements: {
            "_core/(\\w+)": settings.paths.js['core'] + "$1",
            "_core_ext/(\\w+)": settings.paths.js['core-ext'] + "$1",
            "_cartridge/(\\w+)/(\\w+)": settings.paths.js['core-root']
        }
    }, require('aliasify'));
    /*
     * Transform globals into module-like structures
     */
    bundler.transform({global: true},require('browserify-shim'));

    bundler.on('update', function (ids) {
        gulpies.util.log('Changed  ' + gulpies.util.colors.cyan(ids));
        rebundle();
    });
    bundler.on('log', gulpies.util.log);

    function rebundle () {
        return bundler.bundle()
            .on('error', function (e) {
                gulpies.util.log('Browserify Error \n', gulpies.util.colors.red(e));
            })
            .pipe(source('app.js'))
            .pipe(buffer())
            .pipe(gulpies.sourcemaps.init({loadMaps: true}))
            .pipe(compress ? gulpies.uglify() : gulpies.util.noop())
            .pipe(gulpies.sourcemaps.write('./'))
            .pipe(gulp.dest(settings.cartridge_name + settings.paths.js.dest))
            .on('end', function() {
                gulpies.util.log(gulpies.util.colors.magenta('JavaScript compiled'));
            });
    }
    
    return rebundle();
});

/*
 * Compiles CSS
 */
gulp.task ('css', function () {
    var processors = [
            autoprefixer({}),
            imageInliner({assetPaths: [settings.cartridge_name + settings.paths.css.imagessrc + 'base64/']}),
            mqpacker,
            discardComments({removeAll: true})
        ];

    if (watch) {
        gulp.watch(settings.cartridge_name + settings.paths.css.watching, rebuild)
            .on('change', function(e) {
                gulpies.util.log('Changed  ' + gulpies.util.colors.cyan(e.path));
            });
    }
        
    function rebuild () {
        var compliteMessage = gulpies.util.colors.magenta('CSS compiled');
        return gulp.src(settings.cartridge_name + settings.paths.css.src + "*.scss")
            .pipe(gulpies.sourcemaps.init())
            .pipe(gulpies.sass({errLogToConsole: false, outputStyle: 'expanded'})
                    .on("error", gulpies.sass.logError)
                    .on("error", function() {
                        compliteMessage = gulpies.util.colors.red('CSS error');
                    }))
            .pipe(gulpies.sassUnicode())
            .pipe(gulpies.postcss(processors))
            .pipe(compress ? gulpies.minifycss() : gulpies.util.noop())
            .pipe(gulpies.sourcemaps.write ('./') )
            .pipe(gulp.dest(settings.cartridge_name + settings.paths.css.dest))
            .on('error', function() {
                gulpies.util.log(gulpies.util.colors.red('CSS error'));
            })
            .on('end', function() {
                gulpies.util.log(compliteMessage);
            });
    }
    
    return rebuild();
});

/*
 * Compiles Sprites
 */
gulp.task('sprite', function () {
    var spriteData = 
    gulp.src(settings.cartridge_name + settings.paths.css.spritesrc + '*.png')
    .pipe(spritesmith({
        imgName: 'sprite.png',
        imgPath: '../images/sprite.png',
        retinaImgName: 'sprite@2x.png',
        retinaImgPath: '../images/sprite@2x.png',
        retinaSrcFilter: [settings.paths.css.spritesrc + '*@2x.png'],
        cssName: '_sprite.scss',
        algorithm: 'diagonal'
    }));
    spriteData.img.pipe(buffer()).pipe(gulpies.imagemin()).pipe(gulp.dest(settings.cartridge_name + settings.paths.css.spritedest));
    return spriteData.css.pipe(gulp.dest(settings.cartridge_name + settings.paths.css.librariessrc));
});

/*
 * Compiles Iconfont
 */
gulp.task('iconfont', function(){
    return gulp.src(settings.cartridge_name + settings.paths.css.iconfontsrc + '*.svg')
    .pipe(iconfontCss({
        fontName: settings.paths.css.iconfontname,
        path: settings.cartridge_name + settings.paths.css.librariessrc + 'iconfont/_iconfont.scss',
        targetPath: '../../../../../' + settings.cartridge_name + settings.paths.css.librariessrc + 'iconfont/_icons.scss',
        fontPath: '../fonts/'
    })).pipe(iconfont({
        fontName: settings.paths.css.iconfontname,
        formats: ['svg', 'ttf', 'eot', 'woff'],
        normalize: true
    })).pipe(gulp.dest(settings.cartridge_name + settings.paths.css.iconfontdest));
});

/*
 * Watchers
 */
gulp.task('js:watch', ['run-watch-mode', 'js']);
gulp.task ('css:watch', ['run-watch-mode', 'css']);
/*
 * Builders
 */
gulp.task('build', ['run-compress-mode', 'js', 'css']);

/*
 * Validates Pre-Commit JavaScript and DemandwareScript
 */
//TODO
gulp.task('pre-commit', ['js:lint'], guppy.src('pre-commit', function (files) {
    var shjs = require('shelljs'),
        errorFlag = false;

    files.filter(function (filename) {
        return settings.lintCartridges.indexOf(filename.split('/')[0]) !== -1 &&
            filename.match(/\.(ds|js)$/) &&
            filename.indexOf('cartridge/scripts/') !== -1;
    }).forEach(function (filename) {
        var instance = require('dwhint').JSHINT;
        var buffer = [];
        if (shjs.test("-e", filename)) {
            buffer.push.apply(buffer, shjs.cat(filename).split('\n'));
        }
        if (!instance(buffer, {ext_file: 'ds', node: true, '-W100': true, maxcomplexity: false, '-W102' : false }, {"response" : true})) {
            $.util.log($.util.colors.red('lint: ' + filename));
            instance.errors.forEach(function (err) {
            if (err) {
                    errorFlag = true;
                    if (err.code[0] === 'E') {
                        $.util.log($.util.colors.red( '\tline: ' + err.line + ', ' + err.reason));
                    } else {
                        $.util.log($.util.colors.cyan( '\tline: ' + err.line + ', ' + err.reason));
                    }
                }
            });
        } else {
            $.util.log($.util.colors.green('lint: ' + filename));
        }

    });
    if (errorFlag) {
        $.util.colors.red('Reject due to lint errors.')
        process.exit(-1);
    }

    var branch = shjs.exec('git rev-parse --abbrev-ref HEAD', {silent:true}).output;
    if (settings.commitRestrictedBranches.indexOf(branch.trim()) !== -1) {
        $.util.log($.util.colors.red('Direct commits in "' + branch.trim() + '" is disallowed'));
        process.exit(-1);
    }
}));

/*
 * Validates GIT Commit Message
 */
gulp.task('commit-msg', guppy.src('commit-msg', function (commitMsgFile, cb) {
    var msg = require('fs').readFileSync(commitMsgFile) + '';

    if (msg.match(/^(Merge|Revert|Finish)/) || msg.match(new RegExp(settings.git.pattern, 'gm'))) {
        return;
    } else {
        gulpies.util.log(gulpies.util.colors.yellow(
            'Almost there, but here is small issue. Your message format is slightly different than required. ' +
            settings.git.comment));
        process.exit(-1);
    }
}));

/*
 * Demandware Uploading
 */

function uploadDW(files, event) {
    var server = dwdav(dwConfig);
    if (event === 'changed' || event === 'added') {
        Promise.all(files.map(function (f) {
            return server.post(f);
        })).then(function() {
            gulpies.util.log('Uploaded ' + gulpies.util.colors.green(files.join(',')));
        }).catch(function(err) {
            gulpies.util.log(gulpies.util.colors.red('Error uploading ' + files.join(','), err));
        });
    }
    else if (event === 'deleted') {
        Promise.all(files.map(function (f) {
            return server.delete(f);
        })).then(function() {
            gulpies.util.log('Deleted  ' + gulpies.util.colors.green(files.join(',')));
        }).catch(function(err) {
            gulpies.util.log(gulpies.util.colors.red('Error deleting ' + files.join(','), err));
        });
    }

}

gulp.task('upload', function() {
    if (upload) {
        var watchermc = gulp.watch([settings.cartridge_name + settings.paths.watch.cartridgebrand, settings.paths.watch.cartridgecore, '!' + settings.cartridge_name + settings.paths.watch.filter], {readDelay: 1000});
        watchermc.on('change', function (event) {
            uploadDW([event.path], event.type);
        });
    }
});


gulp.task('default', ['run-upload-mode', 'run-watch-mode', 'css', 'js', 'upload']);

// Tasks for Aigis styleguide generation

var aigis = require("gulp-aigis");

gulp.task("styleguide", function() {
    gulp.src('./' + settings.cartridge_name + "/cartridge/static/default/aigis_config.yml")
    .pipe(aigis());
});
